

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="text-bold">Catalogues</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Coupons</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-default">
        <div class="card-header">
          <h4 class="text-center text-bold">
            <?php echo e($title); ?>

            <?php if(isset($coupon)): ?>
              <?php echo e($coupon['coupon_code']); ?>

            <?php endif; ?>
          </h4>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>

        <?php if(Session::has('success_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        
        <form name="couponForm" id="couponForm" 
          <?php if(empty($coupon->id)): ?>
            action="<?php echo e(url('admin/add-edit-coupon')); ?>"
          <?php else: ?>
            action="<?php echo e(url('admin/add-edit-coupon/'.$coupon->id)); ?>"    
          <?php endif; ?> 
          method="POST" enctype="multipart/form-data"
        >
          <?php echo csrf_field(); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <?php if(empty($coupon['coupon_code'])): ?>
                  <div class="form-group">
                    <label for="coupon_option">Coupon Option</label>
                    <br/>
                    <span>
                      <input type="radio" 
                        name="coupon_option" 
                        id="AutomaticCoupon"
                        value="Automatic" 
                        checked
                      >
                      Automatic
                    </span>
                    <br/>
                    <span>
                      <input type="radio" 
                        name="coupon_option" 
                        id="ManualCoupon"
                        value="Manual" 
                      >
                      Manual
                    </span>
                  </div>
                  <div class="form-group" id="couponCode" style="display: none;">
                    <label for="coupon_code">Coupon Code</label>
                    <input type="text" class="form-control" 
                      name="coupon_code" id="coupon_code" 
                      placeholder="Enter Coupon Code" 
                    >
                  </div>
                <?php else: ?>
                  <input type="hidden" name="coupon_option" value="<?php echo e($coupon['coupon_option']); ?>">
                  <input type="hidden" name="coupon_code" value="<?php echo e($coupon['coupon_code']); ?>">
                  <div class="form-group">
                    <label for="coupon_code">Coupon Code</label>
                    <span><?php echo e($coupon['coupon_code']); ?></span>
                  </div>
                <?php endif; ?>
                <div class="form-group">
                  <label for="coupon_type">Coupon Type</label>
                  <br/>
                  <span>
                    <input type="radio" 
                      name="coupon_type"
                      value="Multiple Times" 
                      @if ($coupon['coupon_type'] == "Multiple Times" || empty($coupon['coupon_type'])
                        checked    
                      @endif
                    >
                    Multiple Times
                  </span>
                  <br/>
                  <span>
                    <input type="radio" 
                      name="coupon_type"
                      value="Single Time"
                      <?php if($coupon['coupon_type'] == "Single Time"): ?>
                        checked    
                      <?php endif; ?> 
                    >
                    Single Time
                  </span>
                </div>
                <div class="form-group">
                  <label for="amount_type">Amount Type</label>
                  <br/>
                  <span>
                    <input type="radio" 
                      name="amount_type"
                      value="Percentage" 
                      <?php if($coupon['amount_type'] == "Percentage" || empty($coupon['amount_type'])): ?>
                        checked    
                      <?php endif; ?>
                    >
                    Percentage (in %)
                  </span>
                  <br/>
                  <span>
                    <input type="radio" 
                      name="amount_type"
                      value="Fixed" 
                      <?php if($coupon['amount_type'] == "Fixed"): ?>
                        checked    
                      <?php endif; ?>
                    >
                    Fixed (in USD)
                  </span>
                </div>
                <div class="form-group">
                  <label for="amount">Amount</label>
                  <input type="number" class="form-control" 
                    name="amount" id="amount" 
                    placeholder="Enter Amount"
                    <?php if(!empty($coupon['amount'])): ?>
                      value="<?php echo e($coupon['amount']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('amount')); ?>"    
                    <?php endif; ?> 
                    required
                  >
                </div>
                <div class="form-group">
                  <label>Select Categories</label>
                  <select name="categories[]" class="form-control select2" multiple required>
                    <option value="">Select</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <optgroup label="<?php echo e($section['name']); ?>"></optgroup>
                      
                      <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                          $valParentCat = array($category['id']);
                          foreach ($category['subcategories'] as $subcategory) {
                            array_push($valParentCat, $subcategory['id']);
                          }
                        ?>
                        <option value="<?php echo e(join(",", $valParentCat)); ?>" 
                          <?php if(in_array($category['id'], $selectCats)): ?>
                            selected
                          <?php endif; ?>
                        >
                          &nbsp;--&nbsp;&nbsp;<?php echo e($category['category_name']); ?>

                        </option>
                        <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($subcategory['id']); ?>" 
                            <?php if(in_array($subcategory['id'], $selectCats)): ?>
                              selected
                            <?php endif; ?>
                          >
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;<?php echo e($subcategory['category_name']); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Users</label>
                  <select name="users[]" class="form-control select2" multiple data-live-search="true">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($user['email']); ?>"
                        <?php if(in_array($user['email'], $selectUsers)): ?>
                          selected
                        <?php endif; ?>
                      >
                        <?php echo e($user['email']); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="expiry_date">Expiry Date</label>
                  <input type="text" class="form-control" 
                    name="expiry_date" id="expiry_date" 
                    placeholder="Enter Expiry Date"
                    <?php if(!empty($coupon['expiry_date'])): ?>
                      value="<?php echo e($coupon['expiry_date']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('expiry_date')); ?>"    
                    <?php endif; ?> 
                    data-inputmask-alias="datetime" 
                    data-inputmask-inputformat="yyyy/mm/dd" 
                    data-mask
                    required
                  >
                </div>
              </div>
            </div>
          </div>       
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/coupons/add_edit_coupon.blade.php ENDPATH**/ ?>