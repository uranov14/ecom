

<?php $__env->startSection('content'); ?>
<!-- Page Introduction Wrapper -->
<div class="span9">
  <ul class="breadcrumb">
      <li>
          <a href="<?php echo e(url("/")); ?>">Home</a>
      </li>
      <span class="divider">/</span>
      <li class="active">
          <a href="#"><?php echo e($cmsPageDetails['title']); ?></a>
      </li>
  </ul>
  <h3 align="center"><?php echo e($cmsPageDetails['title']); ?></h3>
  <!-- Cart-Page -->
  <p>
    <?php echo nl2br($cmsPageDetails['description']) ?>
  </p>
  <!-- Cart-Page /- -->
</div>
<!-- Page Introduction Wrapper /- -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front_layouts.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/pages/cms_page.blade.php ENDPATH**/ ?>