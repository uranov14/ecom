<div class="tab-pane" id="listView">
  <?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row">
      <div class="span2">
        <?php if(isset($product['main_image'])): ?>
          <?php
            $product_image_path = "images/product_images/medium/".$product['main_image'];
          ?>
        <?php else: ?>
          <?php
            $product_image_path = "";
          ?>
        <?php endif; ?>
        <?php if(!empty($product['main_image']) && file_exists($product_image_path)): ?>
          <img src="<?php echo e(asset($product_image_path)); ?>" alt="">
        <?php else: ?>
          <img src="<?php echo e(asset('images/product_images/medium/no_image.png')); ?>" alt="">
        <?php endif; ?>
      </div>
      <div class="span4">
        <h3><?php echo e($product['brand']['name']); ?></h3>
        <hr class="soft"/>
        <h4><?php echo e($product['product_name']); ?></h4>
        <p>
          <?php echo e($product['description']); ?>

        </p>
        <a class="btn btn-small pull-right" href="<?php echo e(url('product/'.$product['id'])); ?>">View Details</a>
        <br class="clr"/>
      </div>
      <div class="span3 alignR">
        <form class="form-horizontal qtyFrm">
          <h3> <?php echo e($product['product_price']); ?> $</h3>
          <label class="checkbox">
            <input type="checkbox">  Adds product to compare
          </label><br/>
          
          <a href="product_details.html" class="btn btn-large btn-primary"> Add to <i class=" icon-shopping-cart"></i></a>
          <a href="product_details.html" class="btn btn-large"><i class="icon-zoom-in"></i></a>
          
        </form>
      </div>
    </div>
    <hr class="soft"/>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="tab-pane  active" id="blockView">
  <ul class="thumbnails">
    <?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="span3">
        <div class="thumbnail">
          <a href="<?php echo e(url('product/'.$product['id'])); ?>">
            <?php if(isset($product['main_image'])): ?>
              <?php
                $product_image_path = "images/product_images/medium/".$product['main_image'];
              ?>
            <?php else: ?>
              <?php
                $product_image_path = "";
              ?>
            <?php endif; ?>
            <?php if(!empty($product['main_image']) && file_exists($product_image_path)): ?>
              <img src="<?php echo e(asset($product_image_path)); ?>" alt="">
            <?php else: ?>
              <img src="<?php echo e(asset('images/product_images/medium/no_image.png')); ?>" alt="">
            <?php endif; ?>
          </a>
          <div class="caption">
            <h5><?php echo e($product['product_name']); ?></h5>
            <p>
              <?php echo e($product['brand']['name']); ?> / <?php echo e($product['fabric']); ?>

            </p>
            <?php $discounted_price = App\Models\Product::getDiscountedPrice($product['id']); ?>
            <h4 style="text-align:center">
               
              <a class="btn" href="#">
                Add to <i class="icon-shopping-cart"></i>
              </a> 
              <a class="btn btn-primary" href="#">
                <?php if($discounted_price < $product['product_price']): ?>
                  <del><?php echo e($product['product_price']); ?> $</del>
                  <font color="gold"><?php echo e($discounted_price); ?> $</font>
                <?php else: ?>
                  <?php echo e($product['product_price']); ?> $
                <?php endif; ?>
              </a>
              
            </h4>
          </div>
        </div>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
  <hr class="soft"/>
</div><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/products/ajax_products_listing.blade.php ENDPATH**/ ?>