

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="text-bold">Admins/Sub-Admins</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Admins/Sub-Admins</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-default">
        <div class="card-header">
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
          <h5 class="text-bold"><?php echo e($title); ?></h5>
        </div>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>

        <?php if(Session::has('success_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        <form name="roleForm" id="roleForm" 
          action="<?php echo e(url('admin/update-role/'.$adminDetails['id'])); ?>" 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-md-5">
                <?php if(!empty($adminRoles)): ?>
                  <?php $__currentLoopData = $adminRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role['module'] == "categories"): ?>
                      <?php if($role['view_access'] == 1): ?>
                        <?php $viewCategories = "checked"; ?>
                      <?php else: ?>
                        <?php $viewCategories = ""; ?>
                      <?php endif; ?>
                      <?php if($role['edit_access'] == 1): ?>
                        <?php $editCategories = "checked"; ?>
                      <?php else: ?>
                        <?php $editCategories = ""; ?>
                      <?php endif; ?>
                      <?php if($role['full_access'] == 1): ?>
                        <?php $fullCategories = "checked"; ?>
                      <?php else: ?>
                        <?php $fullCategories = ""; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <?php $viewCategories = ""; ?>
                  <?php $editCategories = ""; ?>
                  <?php $fullCategories = ""; ?>
                <?php endif; ?>
                <div class="form-group">
                  <label>Categories</label>
                  <div>
                    <input type="checkbox" name="categories[view]" style="scale: 1.2;" value="1" <?php if(isset($viewCategories)): ?>
                      <?php echo e($viewCategories); ?>

                    <?php endif; ?>> View Access &nbsp;&nbsp;
                    <input type="checkbox" name="categories[edit]" style="scale: 1.2;" value="1" <?php if(isset($viewCategories)): ?>
                      <?php echo e($editCategories); ?>

                    <?php endif; ?>> Edit Access &nbsp;&nbsp;
                    <input type="checkbox" name="categories[full]" style="scale: 1.2;" value="1" <?php if(isset($viewCategories)): ?>
                      <?php echo e($fullCategories); ?>

                    <?php endif; ?>> Full Access &nbsp;&nbsp;
                  </div>
                </div> 
                <hr>
                <?php if(!empty($adminRoles)): ?>
                  <?php $__currentLoopData = $adminRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role['module'] == "products"): ?>
                      <?php if($role['view_access'] == 1): ?>
                        <?php $viewProducts = "checked"; ?>
                      <?php else: ?>
                        <?php $viewProducts = ""; ?>
                      <?php endif; ?>
                      <?php if($role['edit_access'] == 1): ?>
                        <?php $editProducts = "checked"; ?>
                      <?php else: ?>
                        <?php $editProducts = ""; ?>
                      <?php endif; ?>
                      <?php if($role['full_access'] == 1): ?>
                        <?php $fullProducts = "checked"; ?>
                      <?php else: ?>
                        <?php $fullProducts = ""; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <?php $viewProducts = ""; ?>
                  <?php $editProducts = ""; ?>
                  <?php $fullProducts = ""; ?>
                <?php endif; ?>
                <div class="form-group">
                  <label>Products</label>
                  <div>
                    <input type="checkbox" name="products[view]" style="scale: 1.2;" value="1" <?php if(isset($viewProducts)): ?>
                      <?php echo e($viewProducts); ?>

                    <?php endif; ?>> View Access &nbsp;&nbsp;
                    <input type="checkbox" name="products[edit]" style="scale: 1.2;" value="1" <?php if(isset($editProducts)): ?>
                      <?php echo e($editProducts); ?>

                    <?php endif; ?>> Edit Access &nbsp;&nbsp;
                    <input type="checkbox" name="products[full]" style="scale: 1.2;" value="1" <?php if(isset($fullProducts)): ?>
                      <?php echo e($fullProducts); ?>

                    <?php endif; ?>> Full Access &nbsp;&nbsp;
                  </div>
                </div> 
                <hr>
                <?php if(!empty($adminRoles)): ?>
                  <?php $__currentLoopData = $adminRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role['module'] == "coupons"): ?>
                      <?php if($role['view_access'] == 1): ?>
                        <?php $viewCoupons = "checked"; ?>
                      <?php else: ?>
                        <?php $viewCoupons = ""; ?>
                      <?php endif; ?>
                      <?php if($role['edit_access'] == 1): ?>
                        <?php $editCoupons = "checked"; ?>
                      <?php else: ?>
                        <?php $editCoupons = ""; ?>
                      <?php endif; ?>
                      <?php if($role['full_access'] == 1): ?>
                        <?php $fullCoupons = "checked"; ?>
                      <?php else: ?>
                        <?php $fullCoupons = ""; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <?php $viewCoupons = ""; ?>
                  <?php $editCoupons = ""; ?>
                  <?php $fullCoupons = ""; ?>
                <?php endif; ?>
                <div class="form-group">
                  <label>Coupons</label>
                  <div>
                    <input type="checkbox" name="coupons[view]" style="scale: 1.2;" value="1" <?php if(isset($viewCoupons)): ?>
                      <?php echo e($viewCoupons); ?>

                    <?php endif; ?>> View Access &nbsp;&nbsp;
                    <input type="checkbox" name="coupons[edit]" style="scale: 1.2;" value="1" <?php if(isset($editCoupons)): ?>
                      <?php echo e($editCoupons); ?>

                    <?php endif; ?>> Edit Access &nbsp;&nbsp;
                    <input type="checkbox" name="coupons[full]" style="scale: 1.2;" value="1" <?php if(isset($fullCoupons)): ?>
                      <?php echo e($fullCoupons); ?>

                    <?php endif; ?>> Full Access &nbsp;&nbsp;
                  </div>
                </div>
                <hr> 
                <?php if(!empty($adminRoles)): ?>
                  <?php $__currentLoopData = $adminRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role['module'] == "orders"): ?>
                      <?php if($role['view_access'] == 1): ?>
                        <?php $viewOrders = "checked"; ?>
                      <?php else: ?>
                        <?php $viewOrders = ""; ?>
                      <?php endif; ?>
                      <?php if($role['edit_access'] == 1): ?>
                        <?php $editOrders = "checked"; ?>
                      <?php else: ?>
                        <?php $editOrders = ""; ?>
                      <?php endif; ?>
                      <?php if($role['full_access'] == 1): ?>
                        <?php $fullOrders = "checked"; ?>
                      <?php else: ?>
                        <?php $fullOrders = ""; ?>
                      <?php endif; ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <?php $viewOrders = ""; ?>
                  <?php $editOrders = ""; ?>
                  <?php $fullOrders = ""; ?>
                <?php endif; ?>
                <div class="form-group">
                  <label>Orders</label>
                  <div>
                    <input type="checkbox" name="orders[view]" style="scale: 1.2;" value="1" <?php if(isset($viewOrders)): ?>
                      <?php echo e($viewOrders); ?>

                    <?php endif; ?>> View Access &nbsp;&nbsp;
                    <input type="checkbox" name="orders[edit]" style="scale: 1.2;" value="1" <?php if(isset($editOrders)): ?>
                      <?php echo e($editOrders); ?>

                    <?php endif; ?>> Edit Access &nbsp;&nbsp;
                    <input type="checkbox" name="orders[full]" style="scale: 1.2;" value="1" <?php if(isset($fullOrders)): ?>
                      <?php echo e($fullOrders); ?>

                    <?php endif; ?>> Full Access &nbsp;&nbsp;
                  </div>
                </div> 
                <hr> 
              </div>
            </div>
          </div>       
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/admins/update_role.blade.php ENDPATH**/ ?>