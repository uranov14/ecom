

<?php $__env->startSection('content'); ?>
<div class="span9">
  <div class="well well-small">
    <h4>Featured Products <small class="pull-right"><?php echo e($featuredItemsCount); ?> featured products</small></h4>
    <div class="row-fluid">
      <div id="featured" <?php if($featuredItemsCount > 4): ?> class="carousel slide" <?php endif; ?>>
        <div class="carousel-inner">
          <?php $__currentLoopData = $featuredItemsChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $featuredItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item <?php if($key == 1): ?>
              active
            <?php endif; ?>">
              <ul class="thumbnails">
                <?php $__currentLoopData = $featuredItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="span3">
                    <div class="thumbnail">
                      <i class="tag"></i>
                      <a href="<?php echo e(url('product/'.$item['id'])); ?>">
                        <?php
                          $product_image_path = "public/images/product_images/small/".$item['main_image'];
                        ?>
                        <?php if(!empty($item['main_image']) && file_exists($product_image_path)): ?>
                          <img src="<?php echo e(asset($product_image_path)); ?>" alt="">
                        <?php else: ?>
                          <img src="<?php echo e(asset('public/images/product_images/small/no_image.png')); ?>" alt="">
                        <?php endif; ?>
                      </a>
                      <div class="caption">
                        <?php $discounted_price = App\Models\Product::getDiscountedPrice($item['id']); ?>
                        <h5><?php echo e($item['product_name']); ?></h5>
                        <h4>
                          <a class="btn" href="<?php echo e(url('product/'.$item['id'])); ?>">VIEW</a> 
                          <?php if($discounted_price < $item['product_price']): ?>
                            <del class="pull-right"><?php echo e($item['product_price']); ?> $</del>
                            <br/>
                            <font style="line-height: 24px; margin-top: -.7rem;" color="red" class="pull-right"><?php echo e($discounted_price); ?> $</font>
                          <?php else: ?>
                            <span class="pull-right"><?php echo e($item['product_price']); ?> $</span>
                          <?php endif; ?>
                        </h4>
                      </div>
                    </div>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
      </div>
    </div>
  </div>
  <h4>Latest Products </h4>
  <ul class="thumbnails">
    <?php $__currentLoopData = $newItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li class="span3">
        <div class="thumbnail" style="height: 320px;">
          <a  href="<?php echo e(url('product/'.$item['id'])); ?>">
            <?php
              $product_image_path = "public/images/product_images/small/".$item['main_image'];
            ?>
            <?php if(!empty($item['main_image']) && file_exists($product_image_path)): ?>
              <img width="160" src="<?php echo e(asset($product_image_path)); ?>" alt="">
            <?php else: ?>
              <img width="160" src="<?php echo e(asset('public/images/product_images/small/no_image.png')); ?>" alt="">
            <?php endif; ?>
          </a>
          <div class="caption">
            <?php $discounted_price = App\Models\Product::getDiscountedPrice($item['id']); ?>
            <h5><?php echo e($item['product_name']); ?></h5>
            <p>
              <?php echo e($item['product_code']); ?> (<?php echo e($item['product_color']); ?>)
            </p>
            
            <h4 style="text-align:center">
              
              <a class="btn" href="#">
                Add to 
                <i class="icon-shopping-cart"></i>
              </a> 
              <a class="btn btn-primary" href="#">
                <?php if($discounted_price < $item['product_price']): ?>
                  <del class="pull-right"><?php echo e($item['product_price']); ?> $</del>
                <?php else: ?>
                  <span class="pull-right"><?php echo e($item['product_price']); ?> $</span>
                <?php endif; ?>
              </a>
            </h4>
            <?php if($discounted_price < $item['product_price']): ?>
            <h5 style="color: red;">
              Discounted Price: <?php echo e($discounted_price); ?> $
            </h5>
            <?php endif; ?>
          </div>
        </div>
      </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layouts.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/index.blade.php ENDPATH**/ ?>