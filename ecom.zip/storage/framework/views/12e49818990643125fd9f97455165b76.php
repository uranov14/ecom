

<?php $__env->startSection('content'); ?>
<div class="span9">
  <ul class="breadcrumb">
    <li><a href="index.html">Home</a> <span class="divider">/</span></li>
    <li class="active"> CHECKOUT</li>
  </ul>
  <h3>  CHECKOUT [ <span><span class="totalCartItems"><?php echo e(totalCartItems()); ?></span> Item(s) </span>]
    <a href="<?php echo e(url('cart')); ?>" class="btn btn-large pull-right">
      <i class="icon-arrow-left"></i> 
      Back to Cart 
    </a>
  </h3>	
  <hr class="soft"/>		
  <?php if(Session::has('success_message')): ?>
    <div class="alert alert-success" role="alert">
      <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php Session::forget('success_message'); ?>
  <?php endif; ?>
  <?php if(Session::has('error_message')): ?>
    <div class="alert alert-danger" role="alert">
      <?php echo e(Session::get('error_message')); ?>

      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <?php Session::forget('error_message'); ?>
  <?php endif; ?>
  <form action="<?php echo e(url('/checkout')); ?>" name="checkoutForm" id="checkoutForm" method="POST"><?php echo csrf_field(); ?>
    <table class="table table-bordered">
      <tr>
        <td> 
          <strong>DELIVERY ADDRESSES</strong>
          &nbsp;&nbsp;&nbsp;
          <a href="<?php echo e(url('add-edit-delivery-address')); ?>" class="btn block">Add</a> 
        </td>
      </tr>
      <?php $__currentLoopData = $deliveryAddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr> 
          <td>
            <div class="control-group">
              <input type="radio" 
                name="address_id" id="address<?php echo e($address['id']); ?>" 
                style="margin-top: -3px;"
                shipping_charges="<?php echo e($address['shipping_charges']); ?>"
                total_price="<?php echo e($total_price); ?>"
                coupon_amount="<?php echo e(Session::get('couponAmount')); ?>"
                codpincodeCount="<?php echo e($address['codpincodeCount']); ?>"
                prepaidpincodeCount="<?php echo e($address['prepaidpincodeCount']); ?>"
                value="<?php echo e($address['id']); ?>"
              >
              <span><?php echo e($address['name']); ?>, <?php echo e($address['address']); ?>, <?php echo e($address['city']); ?>, <?php echo e($address['state']); ?>, <?php echo e($address['country']); ?> (<?php echo e($address['pincode']); ?>)</span>
              <span style="float: right;">Mobile: <?php echo e($address['mobile']); ?></span>
            </div>
          </td>
          <td>
            <a href="<?php echo e(url('add-edit-delivery-address/'.$address['id'])); ?>" 
              class="btn btn-warning"
              style="color: black"
            >
              Edit
            </a>
            &nbsp;&nbsp;&nbsp;
            <a href="<?php echo e(url('delete-delivery-address/'.$address['id'])); ?>" class="btn btn-danger addressDelete">Delete</a>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Product</th>
          <th colspan="2">Description</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Discount</th>
          <th>Sub Total</th>
        </tr>
      </thead>
      <tbody>
        <?php $total_price = 0; ?>
        <?php $__currentLoopData = $getCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $attrPrice = App\Models\Product::getDiscountedAttrPrice($item['product_id'], $item['size']);
        ?>
          <tr>
            <td>
              <img width="60" src="<?php echo e(asset('images/product_images/small/'.$item['product']['main_image'])); ?>" alt=""/>
            </td>
            <td colspan="2">
              <?php echo e($item['product']['product_name']); ?> (<?php echo e($item['product']['product_code']); ?>)<br/>
              Color : <?php echo e($item['product']['product_color']); ?><br/>
              Size : <?php echo e($item['size']); ?>

            </td>
            <td><?php echo e($item['quantity']); ?></td>
            <td><?php echo e($attrPrice['product_price'] * $item['quantity']); ?> $</td>
            <td><?php echo e($attrPrice['discount'] * $item['quantity']); ?> $</td>
            <td><?php echo e($attrPrice['final_price'] * $item['quantity']); ?> $</td>
          </tr>
          <?php $total_price += $attrPrice['final_price'] * $item['quantity']; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td colspan="6" style="text-align:right">Sub Total Price:</td>
          <td><?php echo e($total_price); ?>&nbsp;<strong style="font-size: .675rem;">&#x20b4;</strong></td>
        </tr>
        <tr>
          <td colspan="6" style="text-align:right">Coupon Discount:</td>
          <td class="couponAmount">
            <?php if(Session::has('couponAmount')): ?>
              <?php echo e(Session::get('couponAmount')); ?>&nbsp;<strong style="font-size: .675rem;">&#x20b4;</strong>
            <?php else: ?>
              0 $
            <?php endif; ?>
          </td>
        </tr>
        <tr>
          <td colspan="6" style="text-align:right">Shipping Charges:</td>
          <td class="shippingCharges">0&nbsp;<strong style="font-size: .675rem;">&#x20b4;</strong></td>
        </tr>
        <tr>
          <td colspan="6" style="text-align:right"><strong>GRAND TOTAL (<?php echo e($total_price); ?> <strong style="font-size: .675rem;">&#x20b4;</strong> - <span class="couponAmount"><?php echo e(Session::get('couponAmount')); ?> <strong style="font-size: .675rem;">&#x20b4;</strong></span> + <span class="shippingCharges">0 <strong style="font-size: .675rem;">&#x20b4;</strong></span>) </strong></td>
          <td class="label label-important" style="display:block"> <strong class="grand_total"><?php echo e($total_price - Session::get('couponAmount')); ?> &#x20b4;</strong></td>
        </tr>
      </tbody>
    </table>

    <table class="table table-bordered">
      <tbody>
        <tr>
          <td> 
            <div style="display: flex; justify-content:flex-end; margin-right: 2rem;">
              <label class="control-label" style="margin-right: 3rem;"><strong> PAYMENT METHODS: </strong> </label>
              <div class="controls">
                <span class="codMethod">
                  <input type="radio" name="payment_gateway" id="COD" value="COD" style="margin-top: -3px;">&nbsp;&nbsp;<strong>COD</strong>
                </span>
                <br/>
                <span class="prepaidMethod">
                  <input type="radio" name="payment_gateway" id="PayPal" value="PayPal" style="margin-top: -3px;">&nbsp;&nbsp;<strong>PayPal</strong>
                </span>
              </div>
            </div>
          </td>
        </tr>				
      </tbody>
    </table>

    <a href="<?php echo e(url('cart')); ?>" class="btn btn-large"><i class="icon-arrow-left"></i> Back to Cart </a>
    <button type="submit" class="btn btn-large pull-right">Place Order <i class="icon-arrow-right"></i></button>
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layouts.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/products/checkout.blade.php ENDPATH**/ ?>