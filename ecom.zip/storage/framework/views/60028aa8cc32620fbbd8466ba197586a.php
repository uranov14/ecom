

<?php $__env->startSection('content'); ?>
  <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-bold">Settings</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Admin Settings</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="text-center text-bold">Update Admin Details</h4>

                <?php if(Session::has('error_message')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                  <strong>Error: </strong><?php echo e(Session::get('error_message')); ?>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <?php endif; ?>

                <?php if(Session::has('success_message')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                  <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                  <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <?php endif; ?>

                <form 
                  class="forms-sample" 
                  action="<?php echo e(url('admin/update-admin-details')); ?>" 
                  method="POST"
                  id="updateAdminDetailsForm"
                  name="updateAdminDetailsForm"
                  enctype="multipart/form-data"
                >
                <?php echo csrf_field(); ?>
                  <div class="form-group">
                    <label>Admin Email</label>
                    <input class="form-control" value="<?php echo e(Auth::guard('admin')->user()->email); ?>" readonly>
                  </div>
                  <div class="form-group">
                    <label>Admin Type</label>
                    <input class="form-control" value="<?php echo e(Auth::guard('admin')->user()->type); ?>" readonly>
                  </div>
                  <div class="form-group">
                    <label for="admin_name">Name</label>
                    <input type="text" class="form-control" value="<?php echo e(Auth::guard('admin')->user()->name); ?>" name="admin_name" id="admin_name" placeholder="Current Name">
                  </div>
                  <div class="form-group">
                    <label for="admin_mobile">Mobile</label>
                    <input 
                      type="text" 
                      class="form-control" 
                      value="<?php echo e(Auth::guard('admin')->user()->mobile); ?>" 
                      name="admin_mobile" 
                      id="admin_mobile" 
                      placeholder="Enter New Mobile Number"
                      maxlength="12"
                      minlength="10"
                      required
                    >
                  </div>
                  <div class="form-group">
                    <label for="admin_image">Admin Photo</label>
                    <input 
                      type="file" 
                      class="form-control" 
                      value="<?php echo e(Auth::guard('admin')->user()->image); ?>" 
                      name="admin_image" 
                      id="admin_image"
                    >
                    <?php if(!empty(Auth::guard('admin')->user()->image)): ?>
                      <a href="<?php echo e(url('images/admin_images/admin_photos/'.Auth::guard('admin')->user()->image)); ?>" target="_blank">View Photo</a>
                      <input type="hidden" name="current_admin_image" value="<?php echo e(Auth::guard('admin')->user()->image); ?>">
                    <?php endif; ?>
                  </div>
                  <button type="submit" class="btn btn-primary mr-2">Submit</button>
                  <button type="reset" class="btn btn-light">Cancel</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/update_admin_details.blade.php ENDPATH**/ ?>