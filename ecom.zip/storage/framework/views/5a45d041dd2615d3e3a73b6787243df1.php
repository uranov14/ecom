<?php
  use App\Models\Product;
?>
<table class="table table-bordered">
  <thead>
    <tr>
      <th>Product</th>
      <th colspan="2">Description</th>
      <th>Quantity/Update</th>
      <th>Price</th>
      <th>Discount</th>
      <th>Sub Total</th>
    </tr>
  </thead>
  <tbody>
    <?php $total_price = 0; ?>
    <?php $__currentLoopData = $getCartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
      $attrPrice = Product::getDiscountedAttrPrice($item['product_id'], $item['size']);
    ?>
      <tr>
        <td>
          <img width="60" src="<?php echo e(asset('public/images/product_images/small/'.$item['product']['main_image'])); ?>" alt=""/>
        </td>
        <td colspan="2">
          <?php echo e($item['product']['product_name']); ?> (<?php echo e($item['product']['product_code']); ?>)<br/>
          Color : <?php echo e($item['product']['product_color']); ?><br/>
          Size : <?php echo e($item['size']); ?>

        </td>
        <td>
          <div class="input-append">
            <input class="span1" style="max-width:34px" value="<?php echo e($item['quantity']); ?>" id="<?php echo e($item['id']); ?>" size="16" type="text">
            <button class="btn btnQuantityUpdate qtyMinus" data-cartid="<?php echo e($item['id']); ?>" type="button">
              <i class="fas fa-minus icon-minus"></i>
            </button>
            <button class="btn btnQuantityUpdate qtyPlus" data-cartid="<?php echo e($item['id']); ?>" type="button">
              <i class="fas fa-add icon-plus"></i>
            </button>
            <button class="btn btn-danger btnItemDelete" data-cartid="<?php echo e($item['id']); ?>" type="button">
              <i class="icon-remove icon-white"></i>
            </button>				
          </div>
        </td>
        <td><?php echo e($attrPrice['product_price'] * $item['quantity']); ?> $</td>
        <td><?php echo e($attrPrice['discount'] * $item['quantity']); ?> $</td>
        <td><?php echo e($attrPrice['final_price'] * $item['quantity']); ?> $</td>
      </tr>
      <?php $total_price += $attrPrice['final_price'] * $item['quantity']; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td colspan="6" style="text-align:right">Sub Total Price 	</td>
      <td><?php echo e($total_price); ?> $</td>
    </tr>
    <tr>
      <td colspan="6" style="text-align:right">Coupon Discount 	</td>
      <td class="couponAmount">
        <?php if(Session::has('couponAmount')): ?>
          <?php echo e(Session::get('couponAmount')); ?> $
        <?php else: ?>
          0 $
        <?php endif; ?>
      </td>
    </tr>
    <tr>
      <td colspan="6" style="text-align:right"><strong>GRAND TOTAL (<?php echo e($total_price); ?> $ - <span class="couponAmount">0 $</span>) </strong></td>
      <td class="label label-important" style="display:block"> <strong class="grand_total"><?php echo e($total_price); ?> $</strong></td>
    </tr>
  </tbody>
</table><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/products/cart_items.blade.php ENDPATH**/ ?>