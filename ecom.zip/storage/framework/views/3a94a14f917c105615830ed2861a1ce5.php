

<?php $__env->startSection('content'); ?>
<div class="span9">
  <ul class="breadcrumb">
  <li><a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">/</span></li>
  <li class="active">Orders</li>
  </ul>
  <h3>Orders</h3>	
  <hr class="soft"/>
  
  <div class="row">
    <div class="span8">
      <table class="table table-striped table-bordered">
        <thead>
          <tr>
            <th>
              Order ID<br/>(Details)
            </th>
            <th style="text-align: center;">Order Products</th>
            <th>Payment Method</th>
            <th>Grand Total</th>
            <th>Created on</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td style="text-align: center; color:blue; text-decoration: underline; font-size: 1rem;">
                <a style="color: blue;" href="<?php echo e(url('orders/'.$order['id'])); ?>" title="View Details Order">
                  #<?php echo e($order['id']); ?>

                </a>
              </td>
              <td>
                <?php $__currentLoopData = $order['order_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php echo e($product['product_name']); ?>(<?php echo e($product['product_code']); ?>)<br/>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </td>
              <td><?php echo e($order['payment_method']); ?></td>
              <td><?php echo e($order['grand_total']); ?> $</td>
              <td>
                <?php echo e(\Carbon\Carbon::parse($order['created_at'])->isoFormat('Do MMM YYYY')); ?>

              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front_layouts.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/orders/orders.blade.php ENDPATH**/ ?>