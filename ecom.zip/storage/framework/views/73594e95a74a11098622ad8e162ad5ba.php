

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="text-bold">Admins</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Admin & Sub-Admin</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-default">
        <div class="card-header">
          <h4 class="text-bold"><?php echo e($title); ?></h4>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>

        <?php if(Session::has('success_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        
        <form name="adminForm" id="adminForm" 
          <?php if(empty($admin->id)): ?>
            action="<?php echo e(url('admin/add-edit-admin')); ?>"
          <?php else: ?>
            action="<?php echo e(url('admin/add-edit-admin/'.$admin->id)); ?>"    
          <?php endif; ?> 
          method="POST" enctype="multipart/form-data"
        >
          <?php echo csrf_field(); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="admin_name">Admin Name</label>
                  <input type="text" class="form-control" 
                    name="admin_name" id="admin_name" 
                    placeholder="Enter Admin Name"
                    <?php if(!empty($admin['name'])): ?>
                      value="<?php echo e($admin['name']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('admin_name')); ?>"    
                    <?php endif; ?> 
                  >
                </div> 
                <div class="form-group">
                  <label for="admin_mobile">Admin Mobile</label>
                  <input type="text" class="form-control" 
                    name="admin_mobile" id="admin_mobile" 
                    placeholder="Enter Admin Mobile"
                    <?php if(!empty($admin['mobile'])): ?>
                      value="<?php echo e($admin['mobile']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('admin_mobile')); ?>"    
                    <?php endif; ?> 
                  >
                </div> 
                <div class="form-group">
                  <label for="admin_email">Admin Email</label>
                  <input type="email" class="form-control" 
                    name="admin_email" id="admin_email" 
                    placeholder="Enter Admin Email"
                    <?php if(!empty($admin['email'])): ?>
                      value="<?php echo e($admin['email']); ?>"
                      disabled
                    <?php else: ?>
                      value="<?php echo e(old('admin_email')); ?>"  
                      required  
                    <?php endif; ?> 
                  >
                </div>  
                <div class="form-group">
                  <label for="admin_type">Admin Type</label>
                  <select name="admin_type" id="admin_type" 
                    class="form-control select2" 
                    style="width: 100%;"
                    <?php if($admin['id'] != ""): ?>
                      disabled
                    <?php else: ?>
                      required
                    <?php endif; ?>
                  >
                    <option value="">Select</option>
                    <option value="admin"
                      <?php if(!empty($admin['type']) && $admin['type'] == 'admin'): ?>
                        selected
                      <?php endif; ?>
                    >
                      Admin
                    </option>
                    <option value="subadmin"
                      <?php if(!empty($admin['type']) && $admin['type'] == 'subadmin'): ?>
                        selected
                      <?php endif; ?>
                    >
                      Sub-Admin
                    </option>
                  </select>
                </div>
                <div class="form-group">
                  <label for="admin_image">Admin Image</label>
                  <div class="input-group">
                    <div class="custom-file">
                      <input type="file" class="custom-file-input"
                        id="admin_image" name="admin_image" 
                        <?php if(!empty($admin['image'])): ?>
                          value="<?php echo e($admin['image']); ?>"
                        <?php else: ?>
                          value="<?php echo e(old('admin_image')); ?>"  
                        <?php endif; ?>
                      >
                      <label class="custom-file-label" for="main_image">
                        <?php if(!empty($admin['image'])): ?>
                          <?php echo e($admin['image']); ?>

                        <?php else: ?>
                          Choose file
                        <?php endif; ?>
                      </label>
                    </div>
                    <div class="input-group-append">
                      <span class="input-group-text">Upload</span>
                    </div> 
                  </div>
                  <?php if(!empty($admin['image'])): ?>
                    <a href="<?php echo e(url('images/admin_images/admin_photos/'.$admin['image'])); ?>" target="_blank">View Photo</a>
                    <input type="hidden" name="current_admin_image" value="<?php echo e($admin['image']); ?>">
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <label for="admin_password">Admin Password</label>
                  <input type="password" class="form-control" 
                    name="admin_password" id="admin_password" 
                    placeholder="Enter Admin Password"
                    <?php if(!empty($admin['password'])): ?>
                      value="<?php echo e($admin['password']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('admin_password')); ?>"    
                    <?php endif; ?>
                  >
                </div>
              </div>
            </div>
          </div>       
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/admins/add_edit_admin.blade.php ENDPATH**/ ?>