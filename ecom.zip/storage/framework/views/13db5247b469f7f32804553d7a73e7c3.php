

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="text-bold">Catalogues</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Products</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-default">
        <div class="card-header">
          <h4 class="text-center text-bold"><?php echo e($title); ?></h4>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>

        <?php if(Session::has('success_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        
        <?php if(!empty($product->main_image)): ?>
          <div class="mx-auto my-5 d-flex" style="align-items: flex-end;">
            <img src="<?php echo e(asset('images/product_images/small/'.$productdata['main_image'])); ?>" alt="product image"> 
            <a 
              class="confirmDelete btn btn-danger ml-2"
              record="product-image"
              recordid="<?php echo e($productdata['id']); ?>"
              href="javascript:void(0)" 
              style="height: fit-content;"
            >
              Delete Image
            </a>
          </div>   
        <?php endif; ?>
        <form name="productForm" id="productForm" 
          <?php if(empty($product->id)): ?>
            action="<?php echo e(url('admin/add-edit-product')); ?>"
          <?php else: ?>
            action="<?php echo e(url('admin/add-edit-product/'.$product->id)); ?>"    
          <?php endif; ?> 
          method="POST" enctype="multipart/form-data"
        >
          <?php echo csrf_field(); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label>Select Category</label>
                  <select name="category_id" id="category_id" class="form-control select2" style="width: 100%;">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <optgroup label="<?php echo e($section['name']); ?>"></optgroup>
                      <?php $__currentLoopData = $section['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category['id']); ?>" 
                          <?php if(!empty($product['category_id']) && $product['category_id'] == $category['id']): ?>
                            selected
                          <?php endif; ?>
                        >
                          &nbsp;--&nbsp;&nbsp;<?php echo e($category['category_name']); ?>

                        </option>
                        <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($subcategory['id']); ?>" 
                            <?php if(!empty($product['category_id']) && $product['category_id'] == $subcategory['id']): ?>
                              selected
                            <?php endif; ?>
                          >
                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;--&nbsp;&nbsp;<?php echo e($subcategory['category_name']); ?>

                          </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>Select Brand</label>
                  <select name="brand_id" id="brand_id" class="form-control select2" style="width: 100%;">
                    <option value="">Select</option>
                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($brand['id']); ?>"
                        <?php if(!empty($productdata['brand_id']) && $brand['id'] == $productdata['brand_id']): ?>
                          selected
                        <?php endif; ?>
                      >
                        <?php echo e($brand['name']); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group">
                  <label for="product_name">Product Name</label>
                  <input type="text" class="form-control" 
                    name="product_name" id="product_name" 
                    placeholder="Enter Product Name"
                    <?php if(!empty($productdata['product_name'])): ?>
                      value="<?php echo e($productdata['product_name']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('product_name')); ?>"    
                    <?php endif; ?> 
                  >
                </div> 
                <div class="form-group">
                  <label for="product_code">Product Code</label>
                  <input type="text" class="form-control" 
                    name="product_code" id="product_code" 
                    placeholder="Enter Product Code"
                    <?php if(!empty($productdata['product_code'])): ?>
                      value="<?php echo e($productdata['product_code']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('product_code')); ?>"    
                    <?php endif; ?> 
                  >
                </div> 
                <div class="form-group">
                  <label for="product_color">Product Color</label>
                  <input type="text" class="form-control" 
                    name="product_color" id="product_color" 
                    placeholder="Enter Product Color"
                    <?php if(!empty($productdata['product_color'])): ?>
                      value="<?php echo e($productdata['product_color']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('product_color')); ?>"    
                    <?php endif; ?> 
                  >
                </div>  
                <div class="form-group">
                  <label for="product_weight">Product Weight</label>
                  <input type="text" class="form-control" 
                    name="product_weight" id="product_weight" 
                    placeholder="Enter Product Discount"
                    <?php if(!empty($productdata['product_weight'])): ?>
                      value="<?php echo e($productdata['product_weight']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('product_weight')); ?>"    
                    <?php endif; ?> 
                  >
                </div>
                <div class="form-group">
                  <label for="product_price">Product Price</label>
                  <input type="text" class="form-control" 
                    name="product_price" id="product_price" 
                    placeholder="Enter Product Price"
                    <?php if(!empty($productdata['product_price'])): ?>
                      value="<?php echo e($productdata['product_price']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('product_price')); ?>"    
                    <?php endif; ?> 
                  >
                </div> 
                <div class="form-group">
                  <label for="product_discount">Product Discount (%)</label>
                  <input type="text" class="form-control" 
                    name="product_discount" id="product_discount" 
                    placeholder="Enter Product Discount"
                    <?php if(!empty($productdata['product_discount'])): ?>
                      value="<?php echo e($productdata['product_discount']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('product_discount')); ?>"    
                    <?php endif; ?> 
                  >
                </div>
                <div class="form-group">
                  <label for="description">Product Description</label>
                  <textarea class="form-control" 
                    name="description" id="description" 
                    rows="3" placeholder="Enter ..." 
                  >
                  <?php if(!empty($productdata['description'])): ?>
                    <?php echo e($productdata['description']); ?>

                  <?php else: ?>
                    <?php echo e(old('description')); ?>   
                  <?php endif; ?>
                  </textarea>
                </div>
                <div class="form-group">
                  <label for="main_image">Product Main Image</label>
                  <div class="input-group">
                    <div class="custom-file">
                      <input type="file" class="custom-file-input"
                        id="main_image" name="main_image" 
                        <?php if(!empty($productdata['main_image'])): ?>
                          value="<?php echo e($productdata['main_image']); ?>"
                        <?php else: ?>
                          value="<?php echo e(old('main_image')); ?>"  
                        <?php endif; ?>
                      >
                      <label class="custom-file-label" for="main_image">
                        <?php if(!empty($productdata['main_image'])): ?>
                          <?php echo e($productdata['main_image']); ?>

                        <?php else: ?>
                          Choose file
                        <?php endif; ?>
                      </label>
                    </div>
                    <div class="input-group-append">
                      <span class="input-group-text">Upload</span>
                    </div> 
                  </div>
                  <div>
                    <span>Recommended Image Size: Width: 1000px, Height: 1000px</span>
                  </div>
                </div>
                <div class="form-group">
                  <label for="product_video">Product Video</label>
                  <div class="input-group">
                    <div class="custom-file">
                      <input type="file" 
                        class="custom-file-input" 
                        id="product_video" name="product_video"
                      >
                      <label class="custom-file-label" for="product_video">Choose file</label>
                    </div>
                    <div class="input-group-append">
                      <span class="input-group-text" id="">Upload</span>
                    </div>
                  </div>
                  <div>
                    <span>Recommended Video Size: less then 2048 KB</span>
                  </div>
                  <?php if(!empty($productdata['product_video'])): ?>
                    <div><a href="<?php echo e(url('videos/product_videos/'.$productdata['product_video'])); ?>" download>Download</a>&nbsp;|&nbsp;
                      <a class="confirmDelete" href="javascript:void(0)" record="product-video" recordid="<?php echo e($productdata['id']); ?>">Delete Video</a></div>
                  <?php endif; ?>
                </div>
                <div class="form-group">
                  <input type="checkbox" 
                    style="scale: 1.7; margin-left: .2rem;"
                    name="is_featured" id="is_featured" 
                    value="Yes"
                    <?php if(isset($productdata['is_featured']) && $productdata['is_featured'] == "Yes"): ?>
                      checked
                    <?php endif; ?>
                  >
                  <label for="is_featured">&nbsp; &nbsp;Featured</label>
                </div> 
              </div>
              <div class="col-md-6"> 
                <div class="form-group">
                  <label for="group_code">Group Code</label>
                  <input type="text" class="form-control" 
                    name="group_code" id="group_code" 
                    placeholder="Enter Group Code"
                    <?php if(!empty($productdata['group_code'])): ?>
                      value="<?php echo e($productdata['group_code']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('group_code')); ?>"    
                    <?php endif; ?>
                  >
                </div>
                <div class="form-group">
                  <label for="meta_title">Meta Title</label>
                  <input type="text" class="form-control" 
                    name="meta_title" id="meta_title" 
                    placeholder="Enter Meta Title"
                    <?php if(!empty($productdata['meta_title'])): ?>
                      value="<?php echo e($productdata['meta_title']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('meta_title')); ?>"    
                    <?php endif; ?>
                  >
                </div>
                <div class="form-group">
                  <label for="meta_keywords">Meta Keywords</label>
                  <input type="text" class="form-control" 
                    name="meta_keywords" id="meta_keywords" 
                    placeholder="Enter Meta Keywords"
                    <?php if(!empty($productdata['meta_keywords'])): ?>
                      value="<?php echo e($productdata['meta_keywords']); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('meta_keywords')); ?>"    
                    <?php endif; ?>
                  >
                </div>
                <div class="form-group">
                  <label for="meta_description">Meta Description</label>
                  <textarea class="form-control" 
                    name="meta_description" id="meta_description" 
                    rows="3" placeholder="Enter ..."
                  >
                  <?php if(!empty($productdata['meta_description'])): ?>
                    <?php echo e($productdata['meta_description']); ?>

                  <?php else: ?>
                    <?php echo e(old('meta_description')); ?>    
                  <?php endif; ?>
                  </textarea>
                </div>
                <div class="form-group">
                  <label for="wash_care">Wash Care</label>
                  <textarea class="form-control" 
                    name="wash_care" id="wash_care" 
                    rows="3" placeholder="Enter ..." 
                  >
                  <?php if(!empty($product->wash_care)): ?>
                    <?php echo e($product->wash_care); ?>

                  <?php else: ?>
                    <?php echo e(old('wash_care')); ?>   
                  <?php endif; ?>
                  </textarea>
                </div>
                <h4 class="text-bold">Product Filters</h4>
                <div class="filters p-3" style="border: 1px solid #ccc; border-radius: 10px;">
                  <div class="form-group">
                    <label>Select Fabric</label>
                    <select name="fabric" id="fabric" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $productFilters['fabricArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fabric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fabric); ?>"
                          <?php if(!empty($fabric) && $fabric == $product['fabric']): ?>
                            selected
                          <?php endif; ?>
                        >
                          <?php echo e($fabric); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Occasion</label>
                    <select name="occasion" id="occasion" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $productFilters['occasionArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $occasion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($occasion); ?>"
                          <?php if(!empty($occasion) && $occasion == $product['occasion']): ?>
                            selected
                          <?php endif; ?>
                        >
                          <?php echo e($occasion); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Sleeve</label>
                    <select name="sleeve" id="sleeve" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $productFilters['sleeveArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sleeve): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sleeve); ?>"
                          <?php if(!empty($sleeve) && $sleeve == $product['sleeve']): ?>
                            selected
                          <?php endif; ?>
                        >
                          <?php echo e($sleeve); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Pattern</label>
                    <select name="pattern" id="pattern" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $productFilters['patternArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pattern): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pattern); ?>"
                          <?php if(!empty($pattern) && $pattern == $product['pattern']): ?>
                            selected
                          <?php endif; ?>
                        >
                          <?php echo e($pattern); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                  <div class="form-group">
                    <label>Select Fit</label>
                    <select name="fit" id="fit" class="form-control select2" style="width: 100%;">
                      <option value="">Select</option>
                      <?php $__currentLoopData = $productFilters['fitArray']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fit); ?>"
                          <?php if(!empty($fit) && $fit == $product['fit']): ?>
                            selected
                          <?php endif; ?>
                        >
                          <?php echo e($fit); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                  </div>
                </div>
              </div>
            </div>
          </div>       
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/products/add_edit_product.blade.php ENDPATH**/ ?>