<footer class="main-footer">
  <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong>
  All rights reserved.
  <div class="float-right d-none d-sm-inline-block">
    <b>Version</b> 3.2.0
  </div>
</footer><?php /**PATH C:\xampp\htdocs\ecom\resources\views/layouts/admin_layouts/admin_footer.blade.php ENDPATH**/ ?>