

<?php $__env->startSection('content'); ?>
<div class="span9">
  <ul class="breadcrumb">
    <li><a href="index.html">Home</a> <span class="divider">/</span></li>
    <li class="active"> THANKS</li>
  </ul>
  <h3>THANKS !</h3>	
  <hr class="soft"/>		

  <div align="center">
    <h3>
      YOUR ORDER 
      <a href="<?php echo e(url('orders/'.Session::get('order_id'))); ?>" style="color: blue;">
        #<?php echo e(Session::get('order_id')); ?>

      </a> 
      HAS BEEN PLACED SUCCESSFULLY
    </h3>
    <p><strong style="font-size: 1rem;">Grand Total:</strong> <?php echo e(Session::get('grand_total')); ?> $</p>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php
  Session::forget('order_id'); 
  Session::forget('grand_total'); 
?>
<?php echo $__env->make('layouts.front_layouts.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/products/thanks.blade.php ENDPATH**/ ?>