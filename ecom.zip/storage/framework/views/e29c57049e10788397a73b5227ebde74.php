<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<?php if(!empty($meta_title)): ?>
		<title><?php echo e($meta_title); ?></title>
	<?php else: ?>
		<title>Ukrainian Shop</title>
	<?php endif; ?>
	<?php if(!empty($meta_description)): ?>
		<meta name="description" content="<?php echo e($meta_description); ?>">
	<?php else: ?>
		<meta name="description" content="This is test E-commerce Website">
	<?php endif; ?>
	<?php if(!empty($meta_keywords)): ?>
		<meta name="keywords" content="<?php echo e($meta_keywords); ?>">
	<?php else: ?>
		<meta name="keywords" content="selling ukrainian clothes online, sell ukrainian clothes, sell ukrainian dresses online, how to sell ukrainian clothes online">
	<?php endif; ?>
	
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<meta name="author" content="">
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	
	<!-- Front style -->
	<link id="callCss" rel="stylesheet" href="<?php echo e(url('public/css/front_css/front.min.css')); ?>" media="screen"/>
	<link href="<?php echo e(url('public/css/front_css/base.css')); ?>" rel="stylesheet" media="screen"/>
	<link href="<?php echo e(url('public/css/front_css/font-awesome.css')); ?>" rel="stylesheet" media="screen"/>
	<!-- Front style responsive -->
	<link href="<?php echo e(url('public/css/front_css/front-responsive.min.css')); ?>" rel="stylesheet"/>
	
	<!-- Google-code-prettify -->
	<link href="<?php echo e(url('public/js/front_js/google-code-prettify/prettify.css')); ?>" rel="stylesheet"/>
	<!-- fav and touch icons -->
	<link rel="shortcut icon" href="<?php echo e(url('public/images/front_images/ico/favicon.ico')); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo e(url('public/images/front_images/ico/apple-touch-icon-144-precomposed.png')); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo e(url('public/images/front_images/ico/apple-touch-icon-114-precomposed.png')); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo e(url('public/images/front_images/ico/apple-touch-icon-72-precomposed.png')); ?>">
	<link rel="apple-touch-icon-precomposed" href="<?php echo e(url('public/images/front_images/ico/apple-touch-icon-57-precomposed.png')); ?>">
	<style type="text/css" id="enject"></style>
	<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=64d3a6615112d300191669fb&product=sop' async='async'></script>
</head>
<body>
<?php echo $__env->make('layouts.front_layouts.front_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Header End====================================================================== -->

<?php echo $__env->make('front.banners.home_page_banners', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div id="mainBody">
	<div class="container">
		<div class="row">
			<!-- Sidebar ================================================== -->
			<?php echo $__env->make('layouts.front_layouts.front_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- Sidebar end=============================================== -->
			<?php echo $__env->yieldContent('content'); ?>
		</div>
	</div>
</div>
<!-- Footer ================================================================== -->
<?php echo $__env->make('layouts.front_layouts.front_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Placed at the end of the document so the pages load faster ============================================= -->
<script src="<?php echo e(url('public/js/front_js/jquery.js')); ?>" type="text/javascript"></script>
<!-- Validate -->
<script src="<?php echo e(url('public/js/front_js/jquery.validate.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/front_js/front.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(url('public/js/front_js/google-code-prettify/prettify.js')); ?>"></script>

<script src="<?php echo e(url('public/js/front_js/front.js')); ?>"></script>
<script src="<?php echo e(url('public/js/front_js/front_script.js')); ?>"></script>
<script src="<?php echo e(url('public/js/front_js/jquery.lightbox-0.5.js')); ?>"></script>

</body>
</html><?php /**PATH C:\xampp\htdocs\ecom\resources\views/layouts/front_layouts/front_layout.blade.php ENDPATH**/ ?>