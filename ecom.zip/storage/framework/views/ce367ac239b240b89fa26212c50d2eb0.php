
<?php
  use App\Models\Brand;
?>
<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="text-bold">Catalogues</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Products</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">   
            
            <?php if(Session::has('success_message')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>

            <div class="card">
              <div class="card-header">
                <h3 class="text-bold text-center">Products</h3>
                <a href="<?php echo e(url('admin/add-edit-product')); ?>" class="btn btn-block btn-success" style="width: fit-content; float: right;">Add Product</a>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="products" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>ID</th>
                    <th>Product Name (Code)</th>
                    <th>Product Color</th>
                    <th>Product Image</th>
                    <th>Section/Category</th>
                    <th>Brand</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($product->id); ?></td>
                      <td><?php echo e($product->product_name); ?> (<?php echo e($product->product_code); ?>)</td>
                      <td><?php echo e($product->product_color); ?></td>
                      <td class="text-center">
                        <?php
                          $product_image_path = "public/images/product_images/small/".$product->main_image;
                        ?>
                        <?php if(!empty($product->main_image) && file_exists($product_image_path)): ?>
                          <img width="100" src="<?php echo e(asset('public/images/product_images/small/'.$product->main_image)); ?>" alt="product image">
                        <?php else: ?>
                          <img width="100" src="<?php echo e(asset('public/images/product_images/small/no_image.png')); ?>" alt="No image">
                        <?php endif; ?>
                      </td>
                      <td><?php echo e($product->section->name); ?> / <?php echo e($product->category->category_name); ?></td>
                      <?php
                        $brand = Brand::where(['id'=>$product->brand_id, 'status'=>1])->select('name')->first();
                      ?>
                      <td>
                        <?php if($product->brand_id == 0): ?>
                          Not Brand
                        <?php else: ?>
                          <?php echo e($brand['name']); ?>

                        <?php endif; ?>
                      </td>
                      <td style="width: 100px;">
                        <?php if($product->status == 1): ?>
                          <span id="show-status-<?php echo e($product->id); ?>" style=" color: green;">Active</span>
                        <?php else: ?>
                          <span id="show-status-<?php echo e($product->id); ?>" style=" color: red;">Inactive</span>  
                        <?php endif; ?>
                        <br>
                        <?php if($moduleProducts['edit_access'] == 1 || $moduleProducts['full_access'] == 1): ?>
                          <?php if($product->status == 1): ?>
                            <a class="updateProductStatus" 
                              id="product-<?php echo e($product->id); ?>"
                              product_id="<?php echo e($product->id); ?>"
                              href="javascript:;"
                              title="Toggle Status"
                            >
                              <i style="scale: 1.5;" class="fas fa-toggle-on" status="Active"></i>
                            </a>
                          <?php else: ?>
                            <a class="updateProductStatus"
                              id="product-<?php echo e($product->id); ?>" 
                              product_id="<?php echo e($product->id); ?>"
                              href="javascript:;"
                              title="Toggle Status"
                            >
                              <i style="scale: 1.5;" class="fas fa-toggle-off" status="Inactive"></i>
                            </a>
                          <?php endif; ?>
                        <?php endif; ?>
                      </td>
                      <td class="text-center">
                        <?php if($moduleProducts['edit_access'] == 1 || $moduleProducts['full_access'] == 1): ?>
                          <a href="<?php echo e(url('admin/add-attributes/'.$product->id)); ?>" title="Add/Edit Attributes">
                            <i style="scale: 1.2;" class="fas fa-plus"></i>
                          </a>
                          <br>
                          <a href="<?php echo e(url('admin/add-images/'.$product->id)); ?>" title="Add Alternate Images">
                            <i style="scale: 1.5;" class="fas fa-regular fa-file-image"></i>
                          </a>
                          <br>
                          <a href="<?php echo e(url('admin/add-edit-product/'.$product->id)); ?>" title="Edit Product">
                            <i style="scale: 1.2;" class="fas fa-edit"></i>
                          </a>
                          <br>
                        <?php endif; ?>
                        <?php if($moduleProducts['full_access'] == 1): ?>
                          <a 
                            href="javascript:;"
                            class="confirmDelete"
                            record="product"
                            recordid="<?php echo e($product->id); ?>"
                            title="Delete Product"
                          >
                            <i style="scale: 1.2;" class="fas fa-trash"></i>
                          </a>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/products/products.blade.php ENDPATH**/ ?>