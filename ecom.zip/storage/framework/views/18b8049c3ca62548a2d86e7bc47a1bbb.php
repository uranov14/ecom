<link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->
<style>
  .invoice-title h2, .invoice-title h3 {
    display: inline-block;
  }

  .table > tbody > tr > .no-line {
    border-top: none;
  }

  .table > thead > tr > .no-line {
    border-bottom: none;
  }

  .table > tbody > tr > .thick-line {
    border-top: 2px solid;
  }
</style>
<div class="container">
    <div class="row">
        <div class="col-xs-12">
    		<div class="invoice-title">
    			<h2>Invoice</h2>
          <h3 class="pull-right">Order # <?php echo e($orderDetails['id']); ?></h3>
    		</div>
    		<hr>
    		<div class="row">
    			<div class="col-xs-4">
    				<address>
    				  <strong>Billed To:</strong><br>
              <?php echo e($userDetails['name']); ?><br>
              <?php if(!empty($userDetails['address'])): ?>
                <?php echo e($userDetails['address']); ?>,&nbsp;
              <?php endif; ?>
              <?php if(!empty($userDetails['city'])): ?>
                <?php echo e($userDetails['city']); ?>,&nbsp;
              <?php endif; ?>
              <?php if(!empty($userDetails['state'])): ?>
                <?php echo e($userDetails['state']); ?>

              <?php endif; ?>
              <br>
              <?php if(!empty($userDetails['country'])): ?>
                <?php echo e($userDetails['country']); ?>

              <?php endif; ?>
              <?php if(!empty($userDetails['pincode'])): ?>
                (<?php echo e($userDetails['pincode']); ?>)
              <?php endif; ?>
              <br>
              <?php echo e($userDetails['mobile']); ?>

    				</address>
    			</div>
          <div class="col-xs-4">
            <span>
              <?php echo DNS2D::getBarcodeHTML(strval($orderDetails['id']), 'QRCODE'); ?>
            </span>
          </div>
    			<div class="col-xs-4 text-right">
    				<address>
        			<strong>Shipped To:</strong><br>
    					<?php echo e($orderDetails['name']); ?><br>
              <?php echo e($orderDetails['address']); ?>, <?php echo e($orderDetails['city']); ?>, <?php echo e($orderDetails['state']); ?><br>
              <?php echo e($orderDetails['country']); ?> (<?php echo e($orderDetails['pincode']); ?>)<br>
              <?php echo e($orderDetails['mobile']); ?>

    				</address>
    			</div>
    		</div>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
    					<strong>Payment Method:</strong><br>
    					<?php echo e($orderDetails['payment_method']); ?>

    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
    					<strong>Order Date:</strong><br>
    					<?php echo e(date('j F, Y', strtotime($orderDetails['created_at']))); ?>

    				</address>
    			</div>
    		</div>
    	</div>
    </div>
    
    <div class="row">
    	<div class="col-md-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				<h3 class="panel-title"><strong>Order summary</strong></h3>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table class="table table-condensed">
    						<thead>
                  <tr>
                    <td><strong>Item</strong></td>
                    <td class="text-center"><strong>Price</strong></td>
                    <td class="text-center"><strong>Quantity</strong></td>
                    <td class="text-right"><strong>Totals</strong></td>
                  </tr>
    						</thead>
    						<tbody>
                  <?php $subTotal = 0; ?>
    							<?php $__currentLoopData = $orderDetails['order_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        Name: <?php echo e($product['product_name']); ?><br>
                        Code: <?php echo e($product['product_code']); ?><br>
                        Size: <?php echo e($product['product_size']); ?><br>
                        Color: <?php echo e($product['product_color']); ?>

                        <?php echo DNS1D::getBarcodeHTML($product['product_code'], 'C39'); ?>
                      </td>
                      <td class="text-center">$<?php echo e($product['product_price']); ?></td>
                      <td class="text-center"><?php echo e($product['product_qty']); ?></td>
                      <td class="text-right">$<?php echo e($product['product_price'] * $product['product_qty']); ?></td>
                    </tr>
                    <?php $subTotal += $product['product_price'] * $product['product_qty']; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>            
    							<tr>
    								<td class="thick-line"></td>
    								<td class="thick-line"></td>
    								<td class="thick-line text-right"><strong>Sub Total:</strong></td>
    								<td class="thick-line text-right">$<?php echo e($subTotal); ?></td>
    							</tr>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-right"><strong>Shipping:</strong></td>
    								<td class="no-line text-right">$0</td>
    							</tr>
                  <?php if($orderDetails['coupon_amount'] > 0): ?>
                    <tr>
                      <td class="no-line"></td>
                      <td class="no-line"></td>
                      <td class="no-line text-right"><strong>Discount:</strong></td>
                      <td class="no-line text-right">$<?php echo e($orderDetails['coupon_amount']); ?></td>
                    </tr>
                  <?php endif; ?>
    							<tr>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-right"><strong>Grand Total:</strong></td>
    								<td class="no-line text-right">$<?php echo e($orderDetails['grand_total']); ?></td>
    							</tr>
    						</tbody>
    					</table>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/orders/order_invoice.blade.php ENDPATH**/ ?>