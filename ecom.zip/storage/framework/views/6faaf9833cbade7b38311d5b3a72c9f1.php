<div class="form-group">
    <label for="parent_id">Select Category Level</label>
    <select class="form-control"  name="parent_id" id="parent_id">
        <option 
            value="0"
            <?php if(isset($categorydata['parent_id']) && $categorydata['parent_id'] == 0): ?>
                selected
            <?php endif; ?>
        >
            Main Category
        </option> 
        <?php if(!empty($getCategories)): ?>
            <?php $__currentLoopData = $getCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option 
                    value="<?php echo e($category['id']); ?>"
                    <?php if(isset($categorydata['parent_id']) && $categorydata['parent_id'] == $category['id']): ?>
                        selected
                    <?php endif; ?>
                >
                    <?php echo e($category['category_name']); ?>

                </option>

                <?php if(!empty($category['subcategories'])): ?>
                    <?php $__currentLoopData = $category['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option 
                        value="<?php echo e($subcategory['id']); ?>"
                        <?php if(isset($subcategory['parent_id']) && $subcategory['parent_id'] == $subcategory['id']): ?>
                            selected
                        <?php endif; ?>
                    >
                        &nbsp;&raquo;&nbsp;<?php echo e($subcategory['category_name']); ?>

                    </option>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                <?php endif; ?>  

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        <?php endif; ?> 
    </select>
</div><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/categories/append_categories_level.blade.php ENDPATH**/ ?>