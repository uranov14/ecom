

<?php $__env->startSection('content'); ?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="text-bold">Catalogues</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Orders</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">   
            
            <?php if(Session::has('success_message')): ?>
              <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
            <?php endif; ?>

            <div class="card">
              <div class="card-header">
                <h3 class="text-bold text-center">Orders</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="orders" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Order ID</th>
                    <th>Order Date</th>
                    <th>Customer Name</th>
                    <th>Customer Email</th>
                    <th>Ordered Products</th>
                    <th>Order Amount</th>
                    <th>Order Status</th>
                    <th>Payment Method</th>
                    <th>Actions</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($order['id']); ?></td>
                      <td><?php echo e(\Carbon\Carbon::parse($order['created_at'])->isoFormat('Do MMM YYYY')); ?></td>
                      <td><?php echo e($order['name']); ?></td>
                      <td><?php echo e($order['email']); ?></td>
                      <td>
                        <?php $__currentLoopData = $order['order_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php echo e($key+1); ?>) <?php echo e($product['product_name']); ?> * <?php echo e($product['product_qty']); ?><br/>
                          Size: <?php echo e($product['product_size']); ?><br/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </td>
                      <td><?php echo e($order['grand_total']); ?></td>
                      <td><?php echo e($order['order_status']); ?></td>
                      <td><?php echo e($order['payment_method']); ?></td>
                      <td class="text-center">
                        <?php if($moduleOrders['edit_access'] == 1 || $moduleOrders['full_access'] == 1): ?>
                          <a href="<?php echo e(url('admin/orders/'.$order['id'])); ?>" title="View Order Details">
                            <i style="scale: 1.2;" class="fas fa-lightbulb"></i>
                          </a>
                          <br/>
                          <?php if($order['order_status'] == "Shipped" || $order['order_status'] == "Delivered"): ?>
                            <a target="_blank" href="<?php echo e(url('admin/view-order-invoice/'.$order['id'])); ?>" title="View Order Invoice">
                              <i style="scale: 1.2;" class="fas fa-print"></i>
                            </a>
                            <br/>
                            <a target="_blank" href="<?php echo e(url('admin/print-pdf-invoice/'.$order['id'])); ?>" title="Print PDF Invoice">
                              <i style="scale: 1.2;" class="far fa-file-pdf"></i>
                            </a>
                          <?php endif; ?>
                        <?php endif; ?>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div>
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/orders/orders.blade.php ENDPATH**/ ?>