

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="text-bold">Catalogues</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Currencies</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-default">
        <div class="card-header">
          <h4 class="text-center text-bold"><?php echo e($title); ?></h4>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        
        <form name="currencyForm" id="currencyForm" 
          <?php if(empty($currency->id)): ?>
            action="<?php echo e(url('admin/add-edit-currency')); ?>"
          <?php else: ?>
            action="<?php echo e(url('admin/add-edit-currency/'.$currency->id)); ?>"    
          <?php endif; ?> 
          method="POST"
        >
          <?php echo csrf_field(); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="currency_code">Currency Code</label>
                  <input type="text" class="form-control" 
                    name="currency_code" id="currency_code" 
                    placeholder="Enter Currency Code"
                    <?php if(!empty($currency->currency_code)): ?>
                      value="<?php echo e($currency->currency_code); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('currency_code')); ?>"    
                    <?php endif; ?> 
                  >
                </div>  
                <div class="form-group">
                  <label for="exchange_rate">Exchange Rate</label>
                  <input type="text" class="form-control" 
                    name="exchange_rate" id="exchange_rate" 
                    placeholder="Enter Exchange Rate"
                    <?php if(!empty($currency->exchange_rate)): ?>
                      value="<?php echo e($currency->exchange_rate); ?>"
                    <?php else: ?>
                      value="<?php echo e(old('exchange_rate')); ?>"    
                    <?php endif; ?> 
                  >
                </div> 
              </div>
            </div>
          </div>       
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/currencies/add_edit_currency.blade.php ENDPATH**/ ?>