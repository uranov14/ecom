

<?php $__env->startSection('content'); ?>
<div class="span9">
  <ul class="breadcrumb">
    <li><a href="index.html">Home</a> <span class="divider">/</span></li>
    <li class="active"> THANKS</li>
  </ul>
  <h3>THANKS !</h3>	
  <hr class="soft"/>		

  <div align="center">
    <h3>
      YOUR ORDER 
      <a href="<?php echo e(url('orders/'.Session::get('order_id'))); ?>" style="color: blue;">
        #<?php echo e(Session::get('order_id')); ?>

      </a> 
      HAS BEEN PLACED SUCCESSFULLY
    </h3>
    <p><strong style="font-size: 1rem;">Total Payable Amount:</strong> <?php echo e(Session::get('grand_total')); ?> $</p>
    <p>Please make payment by clicking on below Payment button:</p>

    <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post"> 
      <input type="hidden" name="cmd" value="_xclick"> 
      <input type="hidden" name="business" value="sb-pzmdy24352821@business.example.com"> 
      <input type="hidden" name="currency_code" value="USD"> 
      <input type="hidden" name="item_name" value="<?php echo e(Session::get('order_id')); ?>"> 
      <input type="hidden" name="amount" value="<?php echo e(round(Session::get('grand_total'), 2)); ?>"> 
      <input type="hidden" name="first_name" value="<?php echo e($nameArr[0]); ?>"> 
      <input type="hidden" name="last_name" value="<?php echo e($nameArr[1]); ?>"> 
      <input type="hidden" name="address1" value="<?php echo e($orderDetails['address']); ?>"> 
      <input type="hidden" name="address2" value=""> 
      <input type="hidden" name="city" value="<?php echo e($orderDetails['city']); ?>"> 
      <input type="hidden" name="state" value="<?php echo e($orderDetails['state']); ?>"> 
      <input type="hidden" name="country" value="<?php echo e($orderDetails['country']); ?>"> 
      <input type="hidden" name="zip" value="<?php echo e($orderDetails['pincode']); ?>"> 
      <input type="hidden" name="email" value="<?php echo e($orderDetails['email']); ?>">
      <input type="hidden" name="return" value="<?php echo e(url('paypal/success')); ?>"> 
      <input type="hidden" name="cancel_return" value="<?php echo e(url('paypal/fail')); ?>">
      <input type="hidden" name="notify_url" value="<?php echo e(url('paypal/ipn')); ?>">  
      <input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynow_LG.gif" alt="PayPal - The safer, easier way to pay online"> 
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php
  Session::forget('couponCode');
  Session::forget('couponAmount');
?>
<?php echo $__env->make('layouts.front_layouts.front_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/front/paypal/paypal.blade.php ENDPATH**/ ?>