

<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="text-bold">Catalogues</h1>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Product Images</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="container-fluid">
      <!-- SELECT2 EXAMPLE -->
      <div class="card card-default">
        <div class="card-header">
          <h4 class="text-center text-bold"><?php echo e($title); ?></h4>
          <div class="card-tools">
            <button type="button" class="btn btn-tool" data-card-widget="collapse">
              <i class="fas fa-minus"></i>
            </button>
            <button type="button" class="btn btn-tool" data-card-widget="remove">
              <i class="fas fa-times"></i>
            </button>
          </div>
        </div>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>

        <?php if(Session::has('success_message')): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong>Success: </strong><?php echo e(Session::get('success_message')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
        <?php endif; ?>
        
        <form name="addImageForm" id="addImageForm" 
          action="<?php echo e(url('admin/add-images/'.$productdata['id'])); ?>" 
          method="POST"
          enctype="multipart/form-data"
        >
          <?php echo csrf_field(); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                  <label for="product_name">Product Name:</label> &nbsp;<?php echo e($productdata['product_name']); ?>

                </div> 
                <div class="form-group">
                  <label for="product_code">Product Code:</label> &nbsp;<?php echo e($productdata['product_code']); ?>

                </div> 
                <div class="form-group">
                  <label for="product_color">Product Color:</label> &nbsp;<?php echo e($productdata['product_color']); ?>

                </div>  
                <div class="form-group">
                  <label for="product_price">Product Price:</label> &nbsp;<?php echo e($productdata['product_price']); ?>

                </div> 
              </div>
              <div class="col-md-6 my-auto">
                <?php if(!empty($productdata['main_image'])): ?>
                  <div class="d-flex" style="align-items: flex-end; justify-content: center;">
                    <img src="<?php echo e(asset('images/product_images/small/'.$productdata['main_image'])); ?>" alt="product image"> 
                    <a 
                      class="confirmDelete btn btn-danger ml-2"
                      record="product-image"
                      recordid="<?php echo e($productdata['id']); ?>"
                      href="javascript:void(0)" 
                      style="height: fit-content;"
                    >
                      Delete Image
                    </a>
                  </div>   
                <?php endif; ?>
              </div>
              <div class="col-md-6">
                <?php if(Session::has('error_message')): ?>
                  <div class="alert alert-danger alert-dismissible fade show" style="width: fit-content;" role="alert">
                    <strong>Error: </strong><?php echo e(Session::get('error_message')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                <?php endif; ?>
                <div class="form-group">
                  <div class="field_wrapper">
                    <div>
                      <input type="file" id="image" name="image[]" value="" multiple required/>
                    </div>
                </div>
                </div>
              </div>
            </div>
          </div>       
          <div class="card-footer">
            <button type="submit" class="btn btn-primary">Add Images</button>
          </div>
        </form>

        <form name="editImageForm" id="editImageForm" 
          action="<?php echo e(url('admin/edit-images/'.$productdata['id'])); ?>" 
          method="POST"
        ><?php echo csrf_field(); ?>
          <div class="card">
            <div class="card-header">
              <h4 class="text-bold text-center">Added Product Images</h4>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="products" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Image</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $productdata['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input type="text" style="display: none;" name="attrId[]" value="<?php echo e($image['id']); ?>">
                  <tr>
                    <td><?php echo e($image['id']); ?></td>
                    <td>
                      <img width="100" src="<?php echo e(asset('images/product_images/small/'.$image['image'])); ?>" alt="product image">
                    </td>
                    <td>
                      <?php if($image['status'] == 1): ?>
                        <span id="show-status-<?php echo e($image['id']); ?>" style=" color: green;">Active</span>
                      <?php else: ?>
                        <span id="show-status-<?php echo e($image['id']); ?>" style=" color: red;">Inactive</span>  
                      <?php endif; ?>
                    </td>
                    <td>
                      <?php if($image['status'] == 1): ?>
                        <a class="updateImageStatus" 
                          id="image-<?php echo e($image['id']); ?>"
                          image_id="<?php echo e($image['id']); ?>"
                          href="javascript:;"
                          title="toggle status"
                        >
                          <i style="scale: 1.5;" class="fas fa-toggle-on" status="Active"></i>
                        </a>
                      <?php else: ?>
                        <a class="updateImageStatus"
                          id="image-<?php echo e($image['id']); ?>" 
                          image_id="<?php echo e($image['id']); ?>"
                          href="javascript:;"
                          title="toggle status"
                        >
                          <i style="scale: 1.5;" class="fas fa-toggle-off" status="Inactive"></i>
                        </a>
                      <?php endif; ?>
                      <br><br>
                      <a 
                        href="javascript:;"
                        class="confirmDelete"
                        record="image"
                        recordid="<?php echo e($image['id']); ?>"
                        title="delete image"
                      >
                        <i style="scale: 1.5;" class="fas fa-trash"></i>
                      </a>
                    </td>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer">
              <button type="submit" class="btn btn-primary">Update Images</button>
            </div>
            <!-- /.card-body -->
          </div>
        </form>
      </div>
    </div>
    <!-- /.container-fluid -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layouts.admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecom\resources\views/admin/products/add_images.blade.php ENDPATH**/ ?>